package com.example.day4cw1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day4cw1Application {

	public static void main(String[] args) {
		SpringApplication.run(Day4cw1Application.class, args);
	}

}
