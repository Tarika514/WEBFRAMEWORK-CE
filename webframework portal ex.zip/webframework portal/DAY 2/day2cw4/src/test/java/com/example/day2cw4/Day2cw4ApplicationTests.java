package com.example.day2cw4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2cw4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
